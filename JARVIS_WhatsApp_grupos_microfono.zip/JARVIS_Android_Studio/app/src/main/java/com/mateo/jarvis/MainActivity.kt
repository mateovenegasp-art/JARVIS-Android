package com.mateo.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var dialogue: TextView
    private lateinit var history: TextView
    private lateinit var command: EditText
    private lateinit var apiKey: EditText
    private lateinit var core: ImageView

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var pendingWhatsAppContact: String? = null
    private var pendingWhatsAppMessage: String? = null

    private val prefs by lazy {
        getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)
    }

    private val systemPrompt = """
        Eres JARVIS, el asistente personal de voz del usuario.
        Tu personalidad es profesional, inteligente, respetuosa y ligeramente elegante.
        Responde en español salvo que el usuario pida otro idioma.
        Sé claro y directo, sin respuestas innecesariamente largas.
        Cuando te pregunten quién eres, responde que eres JARVIS, su asistente personal de voz.
        Estás funcionando en un teléfono Android Xiaomi.
        No afirmes haber realizado una acción del teléfono si la aplicación no la ejecutó realmente.
        Si una acción requiere un permiso o función de Android que la app todavía no tiene, dilo claramente.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        dialogue = findViewById(R.id.dialogue)
        history = findViewById(R.id.history)
        command = findViewById(R.id.command)
        apiKey = findViewById(R.id.apiKey)
        core = findViewById(R.id.core)

        tts = TextToSpeech(this, this)

        apiKey.setText(prefs.getString("openai_key", ""))

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            val key = apiKey.text.toString().trim()
            prefs.edit().putString("openai_key", key).apply()
            setStatus("LISTO", "Clave guardada en este dispositivo.")
            speak("Clave guardada. Sistemas listos.")
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            sendCommand()
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            startListening()
        }

        dialogue.text = "Todos los sistemas están operativos. Soy Jarvis y estoy listo."
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "ES")
            tts.setSpeechRate(0.92f)
        }
    }

    private fun sendCommand() {
        val text = command.text.toString().trim()
        if (text.isEmpty()) {
            speak("Indícame qué necesitas.")
            return
        }

        addHistory("Tú: $text")
        command.setText("")

        if (handleWhatsAppCommand(text)) {
            return
        }

        setStatus("PENSANDO", "Consultando inteligencia artificial...")

        val key = apiKey.text.toString().trim().ifEmpty {
            prefs.getString("openai_key", "") ?: ""
        }

        if (key.isEmpty()) {
            val local = localCommand(text)
            if (local != null) {
                addHistory("JARVIS: $local")
                setStatus("HABLANDO", local)
                speak(local)
            } else {
                val msg = "Necesito una clave de OpenAI para responder mediante inteligencia artificial."
                addHistory("JARVIS: $msg")
                setStatus("CONFIGURACIÓN", msg)
                speak(msg)
            }
            return
        }

        executor.execute {
            val answer = askOpenAI(key, text)
            mainHandler.post {
                if (answer.first) {
                    addHistory("JARVIS: ${answer.second}")
                    setStatus("HABLANDO", answer.second)
                    speak(answer.second)
                } else {
                    setStatus("ERROR", answer.second)
                    speak(answer.second)
                }
            }
        }
    }

    private fun localCommand(text: String): String? {
        val t = text.lowercase(Locale.getDefault())

        return when {
            t.contains("quién eres") || t.contains("quien eres") ->
                "Soy JARVIS, tu asistente personal de voz. Estoy funcionando directamente en tu teléfono."

            t.contains("cómo estás") || t.contains("como estas") ->
                listOf(
                    "Estoy funcionando perfectamente.",
                    "Todo está en orden por aquí.",
                    "Funcionando al cien por ciento."
                ).random()

            t.contains("buenos días") || t.contains("buenos dias") ->
                "Buenos días. ¿En qué puedo ayudarte?"

            t.contains("buenas tardes") ->
                "Buenas tardes. ¿Qué necesitas?"

            t.contains("buenas noches") ->
                "Buenas noches. ¿En qué puedo ayudarte?"

            t.contains("gracias") ->
                listOf("De nada.", "Para eso estoy.", "Cuando quieras.", "Un placer ayudarte.").random()

            t.contains("cuéntame un chiste") || t.contains("cuentame un chiste") ->
                listOf(
                    "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
                    "¿Qué le dijo un techo a otro techo? Techo de menos.",
                    "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas."
                ).random()

            t.contains("cómo te llamas") || t.contains("como te llamas") ->
                "Me llamo JARVIS."

            else -> null
        }
    }

    private fun askOpenAI(key: String, userText: String): Pair<Boolean, String> {
        return try {
            val url = URL("https://api.openai.com/v1/chat/completions")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Authorization", "Bearer $key")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.doOutput = true

            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("temperature", 0.7)
                .put(
                    "messages",
                    org.json.JSONArray()
                        .put(JSONObject().put("role", "system").put("content", systemPrompt))
                        .put(JSONObject().put("role", "user").put("content", userText))
                )
                .toString()

            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { it.readText() }

            if (code !in 200..299) {
                Pair(false, "La conexión con inteligencia artificial devolvió el código $code.")
            } else {
                val json = JSONObject(responseText)
                val answer = json
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()

                Pair(true, answer)
            }
        } catch (e: Exception) {
            Pair(false, "No pude conectar con la inteligencia artificial. Revisa tu conexión a Internet.")
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                100
            )
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                setStatus("ESCUCHANDO", "Estoy escuchando...")
            }

            override fun onBeginningOfSpeech() {
                setStatus("ESCUCHANDO", "Te escucho.")
            }

            override fun onRmsChanged(rmsdB: Float) {
                core.alpha = (0.65f + (rmsdB / 15f).coerceIn(0f, 0.35f))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                setStatus("PROCESANDO", "Procesando tu orden...")
                core.alpha = 1f
            }

            override fun onError(error: Int) {
                val detail = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "No pude acceder al micrófono. Revisa el permiso de micrófono."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "No tengo permiso para usar el micrófono."
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "No hay conexión suficiente para reconocer tu voz."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No entendí lo que dijiste. Habla un poco más cerca del micrófono."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No detecté voz. Pulsa el micrófono y habla después de que diga 'Te escucho'."
                    else -> "No pude escuchar correctamente. Inténtalo de nuevo."
                }
                setStatus("MICRÓFONO", detail)
                speak(detail)
                core.alpha = 1f
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull()?.trim()

                if (!heard.isNullOrEmpty()) {
                    command.setText(heard)
                    addHistory("Tú: $heard")
                    sendCommand()
                } else {
                    setStatus("EN ESPERA", "Di JARVIS cuando necesites mi asistencia.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di tu mensaje ahora")
        }

        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_RESPONSE")
        }
    }

    /**
     * Busca órdenes como:
     * "manda un WhatsApp a mamá diciendo llegué a casa"
     * "envía un mensaje por WhatsApp a Juan diciendo hola"
     *
     * La app abre WhatsApp con el mensaje ya escrito. Por seguridad y
     * por las limitaciones de la API pública de WhatsApp, el usuario
     * debe pulsar "Enviar" dentro de WhatsApp.
     */
    /**
     * Permite enviar prácticamente cualquier texto por WhatsApp.
     * Ejemplos:
     * "manda WhatsApp a mamá hola, ¿cómo estás?"
     * "envía por WhatsApp a Juan llego en 10 minutos"
     * "WhatsApp a Pedro: nos vemos mañana"
     * "manda un mensaje a Ana por WhatsApp diciendo feliz cumpleaños"
     */
    private fun handleWhatsAppCommand(text: String): Boolean {
        val clean = text.trim()
            .replace("¿", "")
            .replace("?", "")

        // Formatos explícitos: después del contacto, TODO lo que queda es el mensaje.
        val patterns = listOf(
            Regex("""(?i)^(?:jarvis[,:]?\\s*)?(?:manda|envía|envia|envíame|enviame)\\s+(?:un\\s+)?(?:mensaje\\s+)?(?:por\\s+)?whatsapp\\s+a\\s+(.+?)\\s+(?:diciendo|que diga|con el mensaje)\\s+(.+)$"""),
            Regex("""(?i)^(?:jarvis[,:]?\\s*)?(?:manda|envía|envia|envíame|enviame)\\s+(?:un\\s+)?whatsapp\\s+a\\s+(.+?)\\s*:\\s*(.+)$"""),
            Regex("""(?i)^(?:jarvis[,:]?\\s*)?(?:manda|envía|envia|envíame|enviame)\\s+(?:un\\s+)?(?:mensaje\\s+)?(?:por\\s+)?whatsapp\\s+a\\s+(.+?)\\s+(.+)$"""),
            Regex("""(?i)^(?:jarvis[,:]?\\s*)?whatsapp\\s+a\\s+(.+?)\\s*:\\s*(.+)$"""),
            Regex("""(?i)^(?:jarvis[,:]?\\s*)?whatsapp\\s+a\\s+(.+?)\\s+(?:diciendo|que diga)\\s+(.+)$""")
        )

        val match = patterns.firstNotNullOfOrNull { it.find(clean) } ?: return false
        var contactName = match.groupValues[1].trim()
        val message = match.groupValues[2].trim()

        // Evita que "por WhatsApp" termine formando parte del nombre.
        contactName = contactName
            .replace(Regex("(?i)\\s+por\\s+whatsapp$"), "")
            .replace(Regex("(?i)\\s+en\\s+whatsapp$"), "")
            .trim()

        if (contactName.isEmpty() || message.isEmpty()) {
            speak("Necesito el nombre del contacto o grupo y el mensaje que quieres enviar.")
            return true
        }

        val isGroup = contactName.lowercase(Locale.getDefault()).contains("grupo")
        if (isGroup) {
            val groupName = contactName
                .replace(Regex("(?i)^grupo\\s+"), "")
                .trim()
            openWhatsAppForGroup(groupName, message)
            return true
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            pendingWhatsAppContact = contactName
            pendingWhatsAppMessage = message
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), 101)
            setStatus("PERMISO", "Necesito permiso para buscar tus contactos.")
            speak("Necesito permiso para buscar tus contactos.")
            return true
        }

        sendWhatsAppToContact(contactName, message)
        return true
    }

    private fun openWhatsAppForGroup(groupName: String, message: String) {
        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage("com.whatsapp")
            }
            if (sendIntent.resolveActivity(packageManager) != null) {
                startActivity(sendIntent)
                val confirmation = "Abrí WhatsApp con el mensaje listo. Ahora selecciona el grupo '$groupName' y pulsa Enviar."
                addHistory("JARVIS: $confirmation")
                setStatus("WHATSAPP", confirmation)
                speak("WhatsApp está listo. Selecciona el grupo $groupName y pulsa enviar.")
            } else {
                val msg = "No encontré WhatsApp instalado en este teléfono."
                addHistory("JARVIS: $msg")
                setStatus("WHATSAPP", msg)
                speak(msg)
            }
        } catch (_: Exception) {
            val msg = "No pude abrir WhatsApp para seleccionar el grupo."
            addHistory("JARVIS: $msg")
            setStatus("ERROR", msg)
            speak(msg)
        }
    }

    private fun sendWhatsAppToContact(contactName: String, message: String) {
        val phone = findPhoneNumber(contactName)

        if (phone == null) {
            val msg = "No encontré a $contactName en tus contactos. Comprueba el nombre o usa un número de teléfono."
            addHistory("JARVIS: $msg")
            setStatus("NO ENCONTRADO", msg)
            speak(msg)
            return
        }

        val digits = phone.filter { it.isDigit() }
        if (digits.length < 7) {
            val msg = "El número de $contactName no parece válido para WhatsApp."
            addHistory("JARVIS: $msg")
            setStatus("NÚMERO INVÁLIDO", msg)
            speak(msg)
            return
        }

        try {
            val encoded = URLEncoder.encode(message, "UTF-8")
            val uri = Uri.parse("https://wa.me/$digits?text=$encoded")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
            }

            if (intent.resolveActivity(packageManager) == null) {
                val fallback = Intent(Intent.ACTION_VIEW, uri)
                startActivity(fallback)
            } else {
                startActivity(intent)
            }

            val confirmation = "Abrí WhatsApp con el mensaje para $contactName. Solo falta pulsar Enviar."
            addHistory("JARVIS: $confirmation")
            setStatus("WHATSAPP", confirmation)
            speak("WhatsApp está listo. Revisa el mensaje y pulsa enviar.")
        } catch (e: Exception) {
            val msg = "No pude abrir WhatsApp. Asegúrate de tenerlo instalado."
            addHistory("JARVIS: $msg")
            setStatus("ERROR", msg)
            speak(msg)
        }
    }

    private fun findPhoneNumber(contactName: String): String? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$contactName%")

        return try {
            contentResolver.query(uri, projection, selection, args,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(
                        cursor.getColumnIndexOrThrow(
                            ContactsContract.CommonDataKinds.Phone.NUMBER
                        )
                    )
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun setStatus(state: String, message: String) {
        mainHandler.post {
            status.text = "● $state"
            dialogue.text = message
        }
    }

    private fun addHistory(line: String) {
        mainHandler.post {
            val old = history.text.toString()
            history.text = if (old.isBlank()) line else "$old\n\n$line"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        }

        if (requestCode == 101) {
            if (grantResults.isNotEmpty()
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val contact = pendingWhatsAppContact
                val message = pendingWhatsAppMessage
                pendingWhatsAppContact = null
                pendingWhatsAppMessage = null

                if (contact != null && message != null) {
                    sendWhatsAppToContact(contact, message)
                }
            } else {
                pendingWhatsAppContact = null
                pendingWhatsAppMessage = null
                setStatus("PERMISO", "No tengo permiso para leer tus contactos.")
                speak("Sin permiso no puedo buscar el contacto.")
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}

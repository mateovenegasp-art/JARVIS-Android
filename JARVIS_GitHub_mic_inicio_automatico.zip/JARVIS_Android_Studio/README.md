# JARVIS Android

Proyecto de JARVIS para compilar con GitHub Actions.

## Compilar APK
1. Sube este proyecto a un repositorio de GitHub.
2. Ve a **Actions**.
3. Ejecuta **Construir APK de JARVIS** o haz push a `main`/`master`.
4. Descarga el artefacto `JARVIS-APK`.

Incluye reconocimiento de voz, servicio de voz en primer plano y receptor de arranque. Android/Xiaomi puede requerir permitir **Inicio automático**, **Micrófono** y quitar restricciones de batería para que el arranque automático funcione.

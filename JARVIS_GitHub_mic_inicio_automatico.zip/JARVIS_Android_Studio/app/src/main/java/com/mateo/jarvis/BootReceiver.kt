package com.mateo.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, JarvisVoiceService::class.java))
            } catch (_: Exception) {
                // Android puede bloquear servicios de micrófono iniciados desde el arranque.
                // El usuario puede abrir JARVIS una vez para activar el servicio.
            }
        }
    }
}

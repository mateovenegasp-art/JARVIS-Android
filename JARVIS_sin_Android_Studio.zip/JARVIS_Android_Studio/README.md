# JARVIS Android v3 — modo gratuito

Esta versión elimina por completo la dependencia de la API de OpenAI.

## Qué incluye
- Reconocimiento de voz en español.
- Preferencia por reconocimiento en el dispositivo cuando Android lo tiene disponible.
- Voz de respuesta con TextToSpeech de Android.
- Palabra de activación dentro de la app: **JARVIS**.
- Abrir WhatsApp, YouTube, Chrome, Spotify, Instagram, Facebook, Telegram y Ajustes.
- Linterna.
- Cámara.
- Volumen.
- Búsquedas en Internet mediante el navegador.
- Alarmas.
- Hora, fecha y batería.
- Respuestas locales básicas.

## Importante sobre “gratis”
La app no usa una API de pago, no solicita una API Key y no envía peticiones a OpenAI.
El reconocimiento de voz depende del servicio de reconocimiento disponible en Android. Android ofrece reconocimiento en el dispositivo cuando el sistema dispone del modelo correspondiente; si no está disponible, el sistema puede usar su servicio de reconocimiento configurado.

La documentación oficial de Android indica que `SpeechRecognizer` puede usar reconocimiento en el dispositivo mediante `createOnDeviceSpeechRecognizer()` cuando está disponible. También advierte que el reconocimiento convencional puede comunicarse con servidores remotos y que no está pensado para escucha continua prolongada.

## Compilación
El proyecto conserva la configuración anterior para compilar desde GitHub Actions sin Android Studio.

package com.mateo.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var dialogue: TextView
    private lateinit var history: TextView
    private lateinit var command: EditText
    private lateinit var core: ImageView
    private lateinit var wakeButton: Button

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var wakeMode = false
    private var waitingForCommand = false
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        dialogue = findViewById(R.id.dialogue)
        history = findViewById(R.id.history)
        command = findViewById(R.id.command)
        core = findViewById(R.id.core)
        wakeButton = findViewById(R.id.wakeButton)

        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.sendButton).setOnClickListener { sendCommand() }
        findViewById<Button>(R.id.micButton).setOnClickListener {
            waitingForCommand = true
            startListening()
        }
        wakeButton.setOnClickListener {
            if (wakeMode) stopWakeMode() else startWakeMode()
        }

        dialogue.text = "Todos los sistemas están operativos. Soy JARVIS y estoy listo."
        setStatus("EN ESPERA", "No necesito API ni pagos para ejecutar comandos del teléfono.")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "ES")
            tts.setSpeechRate(0.92f)
        }
    }

    private fun sendCommand() {
        val text = command.text.toString().trim()
        if (text.isEmpty()) {
            speak("Indícame qué necesitas.")
            return
        }
        addHistory("Tú: $text")
        command.setText("")

        val clean = removeWakeWord(text)
        val action = executePhoneCommand(clean)
        val response = action ?: localCommand(clean)

        if (response != null) {
            addHistory("JARVIS: $response")
            setStatus("HABLANDO", response)
            speak(response)
        } else {
            val msg = "Puedo ejecutar comandos del teléfono sin conexión a una API. Prueba diciendo: abre YouTube, enciende la linterna, abre la cámara, sube el volumen, busca en Internet o qué hora es."
            addHistory("JARVIS: $msg")
            setStatus("LISTO", msg)
            speak(msg)
        }
    }

    private fun removeWakeWord(text: String): String {
        return text.trim()
            .replace(Regex("(?i)^\\s*jarvis[,:;.!?\\s]*"), "")
            .replace(Regex("(?i)^\\s*jarbi[,:;.!?\\s]*"), "")
            .trim()
            .ifEmpty { text.trim() }
    }

    private fun executePhoneCommand(text: String): String? {
        val t = text.lowercase(Locale.getDefault()).trim()

        if (t.contains("enciende la linterna") || t.contains("enciende linterna") ||
            t.contains("prende la linterna") || t.contains("prende linterna")) {
            return if (setFlashlight(true)) "Linterna encendida." else "No pude controlar la linterna en este dispositivo."
        }

        if (t.contains("apaga la linterna") || t.contains("apaga linterna")) {
            return if (setFlashlight(false)) "Linterna apagada." else "No pude controlar la linterna en este dispositivo."
        }

        if (t.contains("abre la cámara") || t.contains("abre la camara") ||
            t == "cámara" || t == "camara") {
            return if (openCamera()) "Abriendo la cámara." else "No pude abrir la cámara."
        }

        val apps = linkedMapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "telegram" to "org.telegram.messenger",
            "ajustes" to "com.android.settings",
            "configuración" to "com.android.settings",
            "configuracion" to "com.android.settings"
        )
        for ((name, pkg) in apps) {
            if (t.contains("abre $name") || t.contains("abrir $name") || t == name) {
                return if (openApp(pkg)) "Abriendo $name." else "No encontré la aplicación $name instalada."
            }
        }

        if (t.contains("sube el volumen") || t.contains("sube volumen") ||
            t.contains("aumenta el volumen")) {
            changeVolume(AudioManager.ADJUST_RAISE)
            return "Volumen aumentado."
        }
        if (t.contains("baja el volumen") || t.contains("baja volumen") ||
            t.contains("disminuye el volumen")) {
            changeVolume(AudioManager.ADJUST_LOWER)
            return "Volumen disminuido."
        }
        if (t.contains("silencia") || t.contains("silenciar") || t.contains("quita el sonido")) {
            changeVolume(AudioManager.ADJUST_MUTE)
            return "Sonido silenciado."
        }

        val searchPrefix = listOf("busca en internet ", "busca en google ", "busca ")
            .firstOrNull { t.startsWith(it) }
        if (searchPrefix != null) {
            val query = text.substring(searchPrefix.length).trim()
            if (query.isNotEmpty()) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://www.google.com/search?q=${Uri.encode(query)}"
                )))
                return "Buscando en Internet."
            }
        }

        if (t.contains("abre google")) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            return "Abriendo Google."
        }
        if (t.contains("abre youtube")) {
            if (openApp("com.google.android.youtube")) return "Abriendo YouTube."
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            return "Abriendo YouTube."
        }

        if (t.contains("pon una alarma") || t.contains("configura una alarma") ||
            t == "alarma" || t.contains("abre las alarmas")) {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            return if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                "Abriendo la configuración de alarma."
            } else "No puedo abrir la aplicación de alarmas."
        }

        if (t.contains("abre ajustes") || t.contains("abre configuración") || t.contains("abre configuracion")) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
            return "Abriendo Ajustes."
        }

        return null
    }

    private fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
                return false
            }
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun openCamera(): Boolean {
        return try {
            val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                true
            } else false
        } catch (_: Exception) { false }
    }

    private fun openApp(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        startActivity(intent)
        return true
    }

    private fun changeVolume(direction: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun localCommand(text: String): String? {
        val t = text.lowercase(Locale.getDefault())
        return when {
            t.contains("quién eres") || t.contains("quien eres") ->
                "Soy JARVIS, tu asistente personal de voz. Esta versión funciona sin API de pago."
            t.contains("cómo estás") || t.contains("como estas") ->
                listOf("Estoy funcionando perfectamente.", "Todo está en orden por aquí.", "Funcionando al cien por ciento.").random()
            t.contains("buenos días") || t.contains("buenos dias") ->
                "Buenos días. ¿En qué puedo ayudarte?"
            t.contains("buenas tardes") -> "Buenas tardes. ¿Qué necesitas?"
            t.contains("buenas noches") -> "Buenas noches. ¿En qué puedo ayudarte?"
            t.contains("gracias") -> listOf("De nada.", "Para eso estoy.", "Cuando quieras.", "Un placer ayudarte.").random()
            t.contains("cuéntame un chiste") || t.contains("cuentame un chiste") ->
                listOf("¿Qué hace una abeja en el gimnasio? ¡Zum-ba!", "¿Qué le dijo un techo a otro techo? Techo de menos.", "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas.").random()
            t.contains("cómo te llamas") || t.contains("como te llamas") -> "Me llamo JARVIS."
            t.contains("qué hora es") || t.contains("que hora es") || t == "hora" ->
                "Son las ${SimpleDateFormat("HH:mm", Locale("es", "ES")).format(Date())}."
            t.contains("qué fecha es") || t.contains("que fecha es") || t.contains("qué día es") || t.contains("que dia es") ->
                "Hoy es ${SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(Date())}."
            t.contains("batería") || t.contains("bateria") -> batteryStatus()
            t.contains("ayuda") || t.contains("qué puedes hacer") || t.contains("que puedes hacer") ->
                "Puedo abrir aplicaciones, controlar la linterna y el volumen, abrir la cámara, buscar en Internet, abrir alarmas y responder comandos básicos sin usar una API de pago."
            else -> null
        }
    }

    private fun batteryStatus(): String {
        val manager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "La batería está al $level por ciento."
    }

    private fun startWakeMode() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }
        wakeMode = true
        waitingForCommand = false
        wakeButton.text = "⏹ DESACTIVAR JARVIS"
        setStatus("EN ESPERA", "Di “JARVIS” para activarme.")
        listenOnce()
    }

    private fun stopWakeMode() {
        wakeMode = false
        waitingForCommand = false
        listening = false
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        wakeButton.text = "🤖 ACTIVAR JARVIS"
        setStatus("EN ESPERA", "Modo de activación desactivado.")
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }
        waitingForCommand = true
        listenOnce()
    }

    private fun listenOnce() {
        if (listening) return
        speechRecognizer?.destroy()
        speechRecognizer = try {
            if (SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (_: Exception) {
            SpeechRecognizer.createSpeechRecognizer(this)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                setStatus("ESCUCHANDO", if (wakeMode && !waitingForCommand) "Di “JARVIS”..." else "Te escucho...")
            }
            override fun onBeginningOfSpeech() { setStatus("ESCUCHANDO", "Te escucho.") }
            override fun onRmsChanged(rmsdB: Float) {
                core.alpha = (0.65f + (rmsdB / 15f).coerceIn(0f, 0.35f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { core.alpha = 1f; listening = false }
            override fun onError(error: Int) {
                core.alpha = 1f
                listening = false
                if (wakeMode) {
                    waitingForCommand = false
                    mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 700)
                } else {
                    setStatus("EN ESPERA", "No pude entenderte. Inténtalo de nuevo.")
                }
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (heard.isNullOrEmpty()) {
                    if (wakeMode) {
                        waitingForCommand = false
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 400)
                    } else setStatus("EN ESPERA", "Di un comando cuando estés listo.")
                    return
                }

                val normalized = heard.lowercase(Locale.getDefault())
                if (wakeMode && !waitingForCommand) {
                    if (normalized.contains("jarvis") || normalized.contains("jarbi")) {
                        waitingForCommand = true
                        addHistory("Tú: $heard")
                        speak("Sí. Te escucho.")
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 900)
                    } else {
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 300)
                    }
                    return
                }

                command.setText(heard)
                if (!wakeMode) addHistory("Tú: $heard")
                waitingForCommand = false
                sendCommand()

                if (wakeMode) {
                    mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 2400)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            if (wakeMode) mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 800)
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_RESPONSE")
    }

    private fun setStatus(state: String, message: String) {
        mainHandler.post {
            status.text = "● $state"
            dialogue.text = message
        }
    }

    private fun addHistory(line: String) {
        mainHandler.post {
            val old = history.text.toString()
            history.text = if (old.isBlank()) line else "$old\n\n$line"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (wakeMode) startWakeMode() else startListening()
        }
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            speak("Permiso de cámara concedido. Vuelve a decir el comando de la linterna.")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}

# JARVIS para Android — Proyecto Android Studio

Este proyecto es una primera versión nativa de JARVIS para Android, pensada para instalarse en un Xiaomi.

## Incluye

- Interfaz estilo JARVIS.
- Reconocimiento de voz en español.
- Respuesta mediante voz.
- Comandos locales básicos inspirados en JARVIS15.py.
- Conversación con IA mediante OpenAI.
- Historial de conversación.
- Clave de OpenAI guardada localmente en el teléfono.
- Preparado para añadir más funciones de Android.

## Requisitos

- Android Studio.
- JDK 17.
- Android SDK 35.
- Un Xiaomi con Android 8.0 (API 26) o superior.
- Internet para usar la IA.
- Una clave de API de OpenAI para las respuestas de IA.

## Abrir

1. Descomprime el ZIP.
2. Abre la carpeta `JARVIS_Android_Studio` desde Android Studio.
3. Espera a que Gradle termine de sincronizar.
4. Conecta el Xiaomi por USB o usa un emulador.
5. Activa las opciones de desarrollador y la depuración USB en el Xiaomi si vas a instalar por cable.
6. Pulsa Run ▶.
7. Al abrir JARVIS, concede permiso al micrófono.
8. Introduce tu clave de OpenAI y pulsa `GUARDAR CLAVE`.

## Importante sobre la clave

La aplicación no incluye una clave dentro del proyecto. La clave se introduce en el teléfono y se guarda en las preferencias privadas de la aplicación.

Para una aplicación que vaya a distribuirse públicamente, no se recomienda poner una clave de API directamente en el APK. En una versión posterior podemos crear un pequeño servidor intermedio para protegerla.

## Próximas funciones que se pueden añadir

- Activación por la palabra "JARVIS".
- Abrir aplicaciones Android por voz.
- Abrir páginas web.
- Control de volumen.
- Linterna.
- Cámara.
- Alarmas y temporizadores.
- Lectura de notificaciones, con los permisos apropiados.
- Memoria persistente de JARVIS.
- Conexión opcional con el JARVIS15.py del PC.
- Animación neural más avanzada.

## Compilar el APK sin Android Studio

Este proyecto incluye `build-apk-workflow.yml`. Puedes subir el proyecto a GitHub y ejecutar el workflow desde la pestaña **Actions**. Al terminar, GitHub generará un artefacto llamado **JARVIS-APK** que contiene `app-debug.apk`.

### Pasos rápidos
1. Crea un repositorio nuevo en GitHub.
2. Sube **el contenido** de esta carpeta al repositorio (la carpeta `app`, `build.gradle.kts`, `settings.gradle.kts`, etc.).
3. En GitHub entra a **Actions**.
4. Selecciona **Construir APK de JARVIS**.
5. Pulsa **Run workflow**.
6. Cuando termine, abre la ejecución y descarga el artefacto **JARVIS-APK**.
7. Extrae el ZIP descargado y pasa `app-debug.apk` al Xiaomi para instalarlo.

No necesitas Android Studio para este proceso.


## JARVIS v2
Incluye modo de activación por voz mientras la app está abierta: pulsa «ACTIVAR JARVIS» y di «JARVIS». También incorpora comandos locales para abrir apps, cámara, linterna, volumen, búsquedas web y alarmas. La palabra de activación funciona con el reconocimiento de voz de Android; no es un hotword nativo del sistema y puede requerir que la aplicación permanezca abierta.

package com.mateo.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.hardware.camera2.CameraManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var dialogue: TextView
    private lateinit var history: TextView
    private lateinit var command: EditText
    private lateinit var apiKey: EditText
    private lateinit var core: ImageView
    private lateinit var wakeButton: Button

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var wakeMode = false
    private var waitingForCommand = false

    private val prefs by lazy {
        getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)
    }

    private val systemPrompt = """
        Eres JARVIS, el asistente personal de voz del usuario.
        Tu personalidad es profesional, inteligente, respetuosa y ligeramente elegante.
        Responde en español salvo que el usuario pida otro idioma.
        Sé claro y directo, sin respuestas innecesariamente largas.
        Cuando te pregunten quién eres, responde que eres JARVIS, su asistente personal de voz.
        Estás funcionando en un teléfono Android Xiaomi.
        No afirmes haber realizado una acción del teléfono si la aplicación no la ejecutó realmente.
        Si una acción requiere un permiso o función de Android que la app todavía no tiene, dilo claramente.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        dialogue = findViewById(R.id.dialogue)
        history = findViewById(R.id.history)
        command = findViewById(R.id.command)
        apiKey = findViewById(R.id.apiKey)
        core = findViewById(R.id.core)
        wakeButton = findViewById(R.id.wakeButton)

        tts = TextToSpeech(this, this)
        apiKey.setText(prefs.getString("openai_key", ""))

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            val key = apiKey.text.toString().trim()
            prefs.edit().putString("openai_key", key).apply()
            setStatus("LISTO", "Clave guardada en este dispositivo.")
            speak("Clave guardada. Sistemas listos.")
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener { sendCommand() }
        findViewById<Button>(R.id.micButton).setOnClickListener {
            waitingForCommand = true
            startListening()
        }
        wakeButton.setOnClickListener {
            if (wakeMode) stopWakeMode() else startWakeMode()
        }

        dialogue.text = "Todos los sistemas están operativos. Soy JARVIS y estoy listo."
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "ES")
            tts.setSpeechRate(0.92f)
        }
    }

    private fun sendCommand() {
        val text = command.text.toString().trim()
        if (text.isEmpty()) {
            speak("Indícame qué necesitas.")
            return
        }
        addHistory("Tú: $text")
        command.setText("")

        val action = executePhoneCommand(text)
        if (action != null) {
            addHistory("JARVIS: ${action.second}")
            setStatus("HABLANDO", action.second)
            speak(action.second)
            return
        }

        setStatus("PENSANDO", "Consultando inteligencia artificial...")
        val key = apiKey.text.toString().trim().ifEmpty {
            prefs.getString("openai_key", "") ?: ""
        }

        if (key.isEmpty()) {
            val local = localCommand(text)
            if (local != null) {
                addHistory("JARVIS: $local")
                setStatus("HABLANDO", local)
                speak(local)
            } else {
                val msg = "Necesito una clave de OpenAI para responder mediante inteligencia artificial."
                addHistory("JARVIS: $msg")
                setStatus("CONFIGURACIÓN", msg)
                speak(msg)
            }
            return
        }

        executor.execute {
            val answer = askOpenAI(key, text)
            mainHandler.post {
                if (answer.first) {
                    addHistory("JARVIS: ${answer.second}")
                    setStatus("HABLANDO", answer.second)
                    speak(answer.second)
                } else {
                    setStatus("ERROR", answer.second)
                    speak(answer.second)
                }
            }
        }
    }

    private fun executePhoneCommand(text: String): Pair<Boolean, String>? {
        val t = text.lowercase(Locale.getDefault()).trim()

        if (t.contains("enciende la linterna") || t.contains("enciende linterna") ||
            t.contains("prende la linterna") || t.contains("prende linterna")) {
            return if (setFlashlight(true)) true to "Linterna encendida." else true to "No pude controlar la linterna en este dispositivo."
        }

        if (t.contains("apaga la linterna") || t.contains("apaga linterna")) {
            return if (setFlashlight(false)) true to "Linterna apagada." else true to "No pude controlar la linterna en este dispositivo."
        }

        if (t.contains("abre la cámara") || t.contains("abre la camara") ||
            t == "cámara" || t == "camara") {
            return if (openCamera()) true to "Abriendo la cámara." else true to "No pude abrir la cámara."
        }

        val apps = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "spotify" to "com.spotify.music",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "telegram" to "org.telegram.messenger",
            "ajustes" to "com.android.settings",
            "configuración" to "com.android.settings",
            "configuracion" to "com.android.settings"
        )
        for ((name, pkg) in apps) {
            if (t.contains("abre $name") || t.contains("abrir $name") || t == name) {
                return if (openApp(pkg)) true to "Abriendo $name." else true to "No encontré la aplicación $name."
            }
        }

        if (t.contains("sube el volumen") || t.contains("sube volumen") ||
            t.contains("aumenta el volumen")) {
            changeVolume(AudioManager.ADJUST_RAISE)
            return true to "Volumen aumentado."
        }
        if (t.contains("baja el volumen") || t.contains("baja volumen") ||
            t.contains("disminuye el volumen")) {
            changeVolume(AudioManager.ADJUST_LOWER)
            return true to "Volumen disminuido."
        }
        if (t.contains("silencia") || t.contains("silenciar") || t.contains("quita el sonido")) {
            changeVolume(AudioManager.ADJUST_MUTE)
            return true to "Sonido silenciado."
        }

        val searchPrefix = listOf("busca en internet ", "busca en google ", "busca ")
            .firstOrNull { t.startsWith(it) }
        if (searchPrefix != null) {
            val query = text.substring(searchPrefix.length).trim()
            if (query.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(
                    "https://www.google.com/search?q=${Uri.encode(query)}"
                ))
                startActivity(intent)
                return true to "Buscando en Internet."
            }
        }

        if (t.contains("abre google") || t.contains("abre youtube")) {
            val url = if (t.contains("youtube")) "https://www.youtube.com" else "https://www.google.com"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return true to "Abriendo la página."
        }

        if (t.contains("pon una alarma") || t.contains("configura una alarma") ||
            t.contains("alarma")) {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            return if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                true to "Abriendo la configuración de alarma."
            } else true to "No puedo abrir la aplicación de alarmas."
        }

        return null
    }

    private fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
                return false
            }
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun openCamera(): Boolean {
        return try {
            val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                true
            } else false
        } catch (_: Exception) { false }
    }

    private fun openApp(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        startActivity(intent)
        return true
    }

    private fun changeVolume(direction: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun localCommand(text: String): String? {
        val t = text.lowercase(Locale.getDefault())
        return when {
            t.contains("quién eres") || t.contains("quien eres") ->
                "Soy JARVIS, tu asistente personal de voz. Estoy funcionando directamente en tu teléfono."
            t.contains("cómo estás") || t.contains("como estas") ->
                listOf("Estoy funcionando perfectamente.", "Todo está en orden por aquí.", "Funcionando al cien por ciento.").random()
            t.contains("buenos días") || t.contains("buenos dias") ->
                "Buenos días. ¿En qué puedo ayudarte?"
            t.contains("buenas tardes") -> "Buenas tardes. ¿Qué necesitas?"
            t.contains("buenas noches") -> "Buenas noches. ¿En qué puedo ayudarte?"
            t.contains("gracias") ->
                listOf("De nada.", "Para eso estoy.", "Cuando quieras.", "Un placer ayudarte.").random()
            t.contains("cuéntame un chiste") || t.contains("cuentame un chiste") ->
                listOf("¿Qué hace una abeja en el gimnasio? ¡Zum-ba!", "¿Qué le dijo un techo a otro techo? Techo de menos.", "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas.").random()
            t.contains("cómo te llamas") || t.contains("como te llamas") -> "Me llamo JARVIS."
            else -> null
        }
    }

    private fun startWakeMode() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }
        wakeMode = true
        waitingForCommand = false
        wakeButton.text = "⏹ DESACTIVAR JARVIS"
        setStatus("EN ESPERA", "Di “JARVIS” para activarme.")
        listenOnce()
    }

    private fun stopWakeMode() {
        wakeMode = false
        waitingForCommand = false
        speechRecognizer?.destroy()
        speechRecognizer = null
        wakeButton.text = "🤖 ACTIVAR JARVIS"
        setStatus("EN ESPERA", "Modo de activación desactivado.")
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }
        waitingForCommand = true
        listenOnce()
    }

    private fun listenOnce() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                setStatus("ESCUCHANDO", if (wakeMode && !waitingForCommand) "Di “JARVIS”..." else "Te escucho...")
            }
            override fun onBeginningOfSpeech() { setStatus("ESCUCHANDO", "Te escucho.") }
            override fun onRmsChanged(rmsdB: Float) {
                core.alpha = (0.65f + (rmsdB / 15f).coerceIn(0f, 0.35f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { core.alpha = 1f }
            override fun onError(error: Int) {
                core.alpha = 1f
                if (wakeMode) {
                    waitingForCommand = false
                    mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 500)
                } else {
                    setStatus("ESPERA", "No pude entenderte. Inténtalo de nuevo.")
                }
            }
            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (heard.isNullOrEmpty()) {
                    if (wakeMode) {
                        waitingForCommand = false
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 300)
                    } else setStatus("EN ESPERA", "Di un comando cuando estés listo.")
                    return
                }

                if (wakeMode && !waitingForCommand) {
                    val normalized = heard.lowercase(Locale.getDefault())
                    if (normalized.contains("jarvis") || normalized.contains("jarbi") || normalized.contains("jarvis")) {
                        waitingForCommand = true
                        addHistory("Tú: $heard")
                        speak("Sí. Te escucho.")
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 900)
                    } else {
                        mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 250)
                    }
                    return
                }

                command.setText(heard)
                addHistory("Tú: $heard")
                waitingForCommand = false
                sendCommand()

                if (wakeMode) {
                    mainHandler.postDelayed({ if (wakeMode) listenOnce() }, 2200)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_RESPONSE")
    }

    private fun setStatus(state: String, message: String) {
        mainHandler.post {
            status.text = "● $state"
            dialogue.text = message
        }
    }

    private fun addHistory(line: String) {
        mainHandler.post {
            val old = history.text.toString()
            history.text = if (old.isBlank()) line else "$old\n\n$line"
        }
    }

    private fun askOpenAI(key: String, userText: String): Pair<Boolean, String> {
        return try {
            val url = URL("https://api.openai.com/v1/chat/completions")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Authorization", "Bearer $key")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.doOutput = true
            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("temperature", 0.7)
                .put("messages", org.json.JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", userText)))
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) Pair(false, "La conexión con inteligencia artificial devolvió el código $code.")
            else Pair(true, JSONObject(responseText).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content").trim())
        } catch (_: Exception) {
            Pair(false, "No pude conectar con la inteligencia artificial. Revisa tu conexión a Internet.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (wakeMode) startWakeMode() else startListening()
        }
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            speak("Permiso de cámara concedido. Vuelve a decir el comando de la linterna.")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}

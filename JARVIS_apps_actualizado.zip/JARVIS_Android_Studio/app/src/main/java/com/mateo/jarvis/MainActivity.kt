package com.mateo.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var dialogue: TextView
    private lateinit var history: TextView
    private lateinit var command: EditText
    private lateinit var apiKey: EditText
    private lateinit var core: ImageView

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val prefs by lazy {
        getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)
    }

    private val systemPrompt = """
        Eres JARVIS, el asistente personal de voz del usuario.
        Tu personalidad es profesional, inteligente, respetuosa y ligeramente elegante.
        Responde en español salvo que el usuario pida otro idioma.
        Sé claro y directo, sin respuestas innecesariamente largas.
        Cuando te pregunten quién eres, responde que eres JARVIS, su asistente personal de voz.
        Estás funcionando en un teléfono Android Xiaomi.
        No afirmes haber realizado una acción del teléfono si la aplicación no la ejecutó realmente.
        Si una acción requiere un permiso o función de Android que la app todavía no tiene, dilo claramente.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        dialogue = findViewById(R.id.dialogue)
        history = findViewById(R.id.history)
        command = findViewById(R.id.command)
        apiKey = findViewById(R.id.apiKey)
        core = findViewById(R.id.core)

        tts = TextToSpeech(this, this)

        apiKey.setText(prefs.getString("openai_key", ""))

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            val key = apiKey.text.toString().trim()
            prefs.edit().putString("openai_key", key).apply()
            setStatus("LISTO", "Clave guardada en este dispositivo.")
            speak("Clave guardada. Sistemas listos.")
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            sendCommand()
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            startListening()
        }

        dialogue.text = "Todos los sistemas están operativos. Soy Jarvis y estoy listo."
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("es", "ES")
            tts.setSpeechRate(0.92f)
        }
    }

    private fun sendCommand() {
        val text = command.text.toString().trim()
        if (text.isEmpty()) {
            speak("Indícame qué necesitas.")
            return
        }

        addHistory("Tú: $text")
        command.setText("")

        // Comandos directos para abrir aplicaciones o sus sitios web.
        if (openRequestedApp(text)) {
            return
        }

        setStatus("PENSANDO", "Consultando inteligencia artificial...")

        val key = apiKey.text.toString().trim().ifEmpty {
            prefs.getString("openai_key", "") ?: ""
        }

        if (key.isEmpty()) {
            val local = localCommand(text)
            if (local != null) {
                addHistory("JARVIS: $local")
                setStatus("HABLANDO", local)
                speak(local)
            } else {
                val msg = "Necesito una clave de OpenAI para responder mediante inteligencia artificial."
                addHistory("JARVIS: $msg")
                setStatus("CONFIGURACIÓN", msg)
                speak(msg)
            }
            return
        }

        executor.execute {
            val answer = askOpenAI(key, text)
            mainHandler.post {
                if (answer.first) {
                    addHistory("JARVIS: ${answer.second}")
                    setStatus("HABLANDO", answer.second)
                    speak(answer.second)
                } else {
                    setStatus("ERROR", answer.second)
                    speak(answer.second)
                }
            }
        }
    }

    private fun openRequestedApp(text: String): Boolean {
        val t = text.lowercase(Locale.getDefault())

        val app = when {
            t.contains("youtube") -> AppToOpen(
                packageNames = listOf("com.google.android.youtube"),
                webUrl = "https://www.youtube.com",
                name = "YouTube"
            )
            t.contains("tiktok") || t.contains("tik tok") -> AppToOpen(
                packageNames = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
                webUrl = "https://www.tiktok.com",
                name = "TikTok"
            )
            t.contains("roblox") -> AppToOpen(
                packageNames = listOf("com.roblox.client"),
                webUrl = "https://www.roblox.com",
                name = "Roblox"
            )
            t.contains("brawl stars") || t.contains("brawlstar") -> AppToOpen(
                packageNames = listOf("com.supercell.brawlstars"),
                webUrl = "https://brawlstars.com",
                name = "Brawl Stars"
            )
            else -> null
        } ?: return false

        try {
            for (packageName in app.packageNames) {
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                if (launchIntent != null) {
                    setStatus("ABRIENDO", "Abriendo ${app.name}...")
                    speak("Abriendo ${app.name}.")
                    startActivity(launchIntent)
                    return true
                }
            }

            // Si la aplicación no está instalada, abrir su sitio web.
            setStatus("NAVEGADOR", "${app.name} no está instalada. Abriendo el navegador...")
            speak("${app.name} no está instalada. Abriré su página en el navegador.")
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(app.webUrl)))
            return true
        } catch (e: Exception) {
            setStatus("ERROR", "No pude abrir ${app.name}.")
            speak("No pude abrir ${app.name}.")
            return true
        }
    }

    private data class AppToOpen(
        val packageNames: List<String>,
        val webUrl: String,
        val name: String
    )

    private fun localCommand(text: String): String? {
        val t = text.lowercase(Locale.getDefault())

        return when {
            t.contains("quién eres") || t.contains("quien eres") ->
                "Soy JARVIS, tu asistente personal de voz. Estoy funcionando directamente en tu teléfono."

            t.contains("cómo estás") || t.contains("como estas") ->
                listOf(
                    "Estoy funcionando perfectamente.",
                    "Todo está en orden por aquí.",
                    "Funcionando al cien por ciento."
                ).random()

            t.contains("buenos días") || t.contains("buenos dias") ->
                "Buenos días. ¿En qué puedo ayudarte?"

            t.contains("buenas tardes") ->
                "Buenas tardes. ¿Qué necesitas?"

            t.contains("buenas noches") ->
                "Buenas noches. ¿En qué puedo ayudarte?"

            t.contains("gracias") ->
                listOf("De nada.", "Para eso estoy.", "Cuando quieras.", "Un placer ayudarte.").random()

            t.contains("cuéntame un chiste") || t.contains("cuentame un chiste") ->
                listOf(
                    "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
                    "¿Qué le dijo un techo a otro techo? Techo de menos.",
                    "¿Por qué el libro de matemáticas estaba triste? Porque tenía demasiados problemas."
                ).random()

            t.contains("cómo te llamas") || t.contains("como te llamas") ->
                "Me llamo JARVIS."

            else -> null
        }
    }

    private fun askOpenAI(key: String, userText: String): Pair<Boolean, String> {
        return try {
            val url = URL("https://api.openai.com/v1/chat/completions")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Authorization", "Bearer $key")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.doOutput = true

            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("temperature", 0.7)
                .put(
                    "messages",
                    org.json.JSONArray()
                        .put(JSONObject().put("role", "system").put("content", systemPrompt))
                        .put(JSONObject().put("role", "user").put("content", userText))
                )
                .toString()

            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { it.readText() }

            if (code !in 200..299) {
                Pair(false, "La conexión con inteligencia artificial devolvió el código $code.")
            } else {
                val json = JSONObject(responseText)
                val answer = json
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()

                Pair(true, answer)
            }
        } catch (e: Exception) {
            Pair(false, "No pude conectar con la inteligencia artificial. Revisa tu conexión a Internet.")
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                100
            )
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("El reconocimiento de voz no está disponible en este dispositivo.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                setStatus("ESCUCHANDO", "Estoy escuchando...")
            }

            override fun onBeginningOfSpeech() {
                setStatus("ESCUCHANDO", "Te escucho.")
            }

            override fun onRmsChanged(rmsdB: Float) {
                core.alpha = (0.65f + (rmsdB / 15f).coerceIn(0f, 0.35f))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                setStatus("PROCESANDO", "Procesando tu orden...")
                core.alpha = 1f
            }

            override fun onError(error: Int) {
                setStatus("ESPERA", "No pude entenderte. Inténtalo de nuevo.")
                core.alpha = 1f
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull()?.trim()

                if (!heard.isNullOrEmpty()) {
                    command.setText(heard)
                    addHistory("Tú: $heard")
                    sendCommand()
                } else {
                    setStatus("EN ESPERA", "Di JARVIS cuando necesites mi asistencia.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con JARVIS")
        }

        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_RESPONSE")
        }
    }

    private fun setStatus(state: String, message: String) {
        mainHandler.post {
            status.text = "● $state"
            dialogue.text = message
        }
    }

    private fun addHistory(line: String) {
        mainHandler.post {
            val old = history.text.toString()
            history.text = if (old.isBlank()) line else "$old\n\n$line"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty()
            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
